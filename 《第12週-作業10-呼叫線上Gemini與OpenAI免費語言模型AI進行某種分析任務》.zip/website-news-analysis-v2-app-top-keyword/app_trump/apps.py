from django.apps import AppConfig


class AppTopPersonConfig(AppConfig):
    name = 'app_trump'
