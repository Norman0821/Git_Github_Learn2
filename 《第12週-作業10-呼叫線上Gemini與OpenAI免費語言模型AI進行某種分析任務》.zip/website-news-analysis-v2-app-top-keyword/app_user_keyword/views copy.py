import pandas as pd
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime, timedelta
import ast

# 讀取資料
def load_df_data():
    df = pd.read_csv('app_user_keyword/dataset/udn_to_django_format.csv', sep='|')  # 更新檔案路徑
    return df

# 首頁
def home(request):
    return render(request, 'app_user_keyword/home.html')

@csrf_exempt
def api_get_top_userkey(request):
    # 接收前端的參數
    userkey = request.POST.get('userkey')
    cate = request.POST.get('cate')
    cond = request.POST.get('cond')
    weeks = int(request.POST.get('weeks'))
    base_date = request.POST.get('base_date')  # 接收基準日期
    key = userkey.split()  # 多個關鍵字
    
    # 讀取資料
    df = load_df_data()

    # 設定日期範圍
    end_date = df['date'].max()  # 資料中的最大日期
    start_date = (datetime.strptime(end_date, '%Y-%m-%d') - timedelta(weeks=weeks)).strftime('%Y-%m-%d')

    # 篩選資料
    df_query = filter_dataFrame(df, key, cond, cate, start_date, end_date)

    # 統計關鍵字出現的頻率
    key_freq_cat, key_occurrence_cat = count_keyword(df_query, key)

    # 根據時間統計關鍵字出現頻率
    key_time_freq = get_keyword_time_based_freq(df_query)

    # 返回結果
    response = {
        'key_occurrence_cat': key_occurrence_cat,
        'key_freq_cat': key_freq_cat,
        'key_time_freq': key_time_freq,
    }

    return JsonResponse(response)

# 進行資料篩選
def filter_dataFrame(df, user_keywords, cond, cate, start_date, end_date):
    if cate == "全部" and cond == 'and':
        df_query = df[(df['date'] >= start_date) & (df['date'] <= end_date) 
            & df['content'].apply(lambda text: all(qk in text for qk in user_keywords))]
    elif cate == "全部" and cond == 'or':
        df_query = df[(df['date'] >= start_date) & (df['date'] <= end_date) 
            & df['content'].apply(lambda text: any(qk in text for qk in user_keywords))]
    elif cond == 'and':
        df_query = df[(df['category'] == cate) & (df['date'] >= start_date) & (df['date'] <= end_date) 
            & df['content'].apply(lambda text: all(qk in text for qk in user_keywords))]
    elif cond == 'or':
        df_query = df[(df['category'] == cate) & (df['date'] >= start_date) & (df['date'] <= end_date) 
            & df['content'].apply(lambda text: any(qk in text for qk in user_keywords))]
    return df_query

# 計算關鍵字出現次數
def count_keyword(df_query, user_keywords):
    cate_occurence = {cate: 0 for cate in ['要聞', '社會', '股市', '全球', '地方', '產經', '文教', '評論', '兩岸', '全部']}
    cate_freq = {cate: 0 for cate in ['要聞', '社會', '股市', '全球', '地方', '產經', '文教', '評論', '兩岸', '全部']}
    
    for idx, row in df_query.iterrows():
        cate_occurence[row['category']] += 1
        cate_occurence['全部'] += 1
        tokens = ast.literal_eval(row['tokens_v2'])  # 使用 ast.literal_eval 來安全解析 tokens_v2
        freq = sum([1 for word in tokens if word in user_keywords])
        cate_freq[row['category']] += freq
        cate_freq['全部'] += freq

    # 過濾重複項目，保證每個類別只顯示一次
    unique_cate_occurence = {key: cate_occurence[key] for key in set(cate_occurence)}
    unique_cate_freq = {key: cate_freq[key] for key in set(cate_freq)}

    return unique_cate_freq, unique_cate_occurence

# 根據日期統計關鍵字出現頻率
def get_keyword_time_based_freq(df_query):
    df_query['date'] = pd.to_datetime(df_query['date'])
    time_data = df_query.groupby(df_query['date'].dt.date).size().reset_index(name='count')
    time_data = [{'x': str(row['date']), 'y': row['count']} for _, row in time_data.iterrows()]
    return time_data
