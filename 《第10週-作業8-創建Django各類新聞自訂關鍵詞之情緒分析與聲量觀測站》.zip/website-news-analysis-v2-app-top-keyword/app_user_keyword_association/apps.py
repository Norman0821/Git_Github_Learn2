from django.apps import AppConfig


class AppUserKeywordAssociationConfig(AppConfig):
    name = 'app_user_keyword_association'
