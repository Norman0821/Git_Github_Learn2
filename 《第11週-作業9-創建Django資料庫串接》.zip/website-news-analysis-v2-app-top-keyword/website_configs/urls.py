from django.contrib import admin
from django.urls import path
from django.urls import include

urlpatterns = [
    # top keywords
    path('topword/', include('app_top_keyword.urls')),
    path('topperson/', include('app_top_person.urls')),
    path('userkeyword/', include('app_user_keyword.urls')),
    path('trump/', include('app_trump.urls')),
    path('assoc/', include('app_user_keyword_association.urls')),
    # user keyword sentiment 
    path('userkeyword_senti/', include('app_user_keyword_sentiment.urls')),
    # travel mayor election
    path('travelmayor/', include('app_travel_mayor.urls')),
    path('userkeyword_db/', include('app_user_keyword_db.urls')),
    path('topperson_db/', include('app_top_person_db.urls')),
    

    # admin 後台資料庫管理介面
    path('admin/', admin.site.urls),

]
