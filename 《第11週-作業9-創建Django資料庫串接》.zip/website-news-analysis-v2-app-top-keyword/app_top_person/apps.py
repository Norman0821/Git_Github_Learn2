from django.apps import AppConfig


class AppTopPersonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_top_person'
